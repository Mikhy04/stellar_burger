export type TAppHeaderUIProps = {
  userName: string | undefined;
};
