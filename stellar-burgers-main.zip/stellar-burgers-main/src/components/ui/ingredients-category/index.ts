export { IngredientsCategoryUI } from './ingredients-category';
